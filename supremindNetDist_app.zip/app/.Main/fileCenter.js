"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileCenter = void 0;
const electron_1 = require("electron");
const fs = require("fs");
const moment = require("moment");
const path = require("path");
const Store = require("electron-store");
class FileCenter {
    constructor() {
        this.fileTitle = '编号,X,Y,深度,GPS高程,GPS状态';
        this.store = new Store({
            name: 'config'
        });
    }
    readFile(filePath) {
        const lastFilePath = this.store.get('lastFilePath');
        if (filePath !== lastFilePath) {
            this.save(filePath, [], [], []);
        }
        const content = fs.readFileSync(filePath, { encoding: 'utf8' });
        const positions = content.toString().split('\r\n');
        positions.shift();
        this.sendToRender(positions);
    }
    sendToRender(positions) {
        global.mainWindow.webContents.send('positions', positions);
    }
    getDataFromRender(params) {
        this.lastExportParams = params;
        global.mainWindow.webContents.send('getDataSource');
    }
    saveAs(data) {
        const { dataSource = [], dataArray = [] } = data;
        const downloadPath = this.store.get('downloadPath');
        const { mime, interval, gpsStatus } = this.lastExportParams;
        const content = [this.fileTitle];
        let curInterval = 0;
        dataSource.forEach((d, index) => {
            const arr = d.split(',');
            arr[3] = dataArray[index] || arr[3];
            if ((+arr[arr.length - 1] === gpsStatus || gpsStatus === 0) &&
                curInterval === 0) {
                content.push(arr.join(','));
            }
            curInterval++;
            if (curInterval > interval - 1) {
                curInterval = 0;
            }
        });
        const filePath = path.join(downloadPath || electron_1.app.getPath('downloads'), moment().format('YYYYMMDDHHmmss') + (mime === 'CSV' ? '.csv' : '.txt'));
        // TODO 更具数据参数存储到文件
        fs.writeFileSync(filePath, (mime === 'CSV' ? `\ufeff` : '') + content.join('\r\n'), { encoding: 'utf8' });
        return filePath;
    }
    save(lastFilePath, lastDatarray, lastHostory, lastDataSource) {
        if (lastFilePath) {
            this.store.set('lastFilePath', lastFilePath);
        }
        if (lastDatarray) {
            this.store.set('lastDatarray', lastDatarray);
        }
        if (lastHostory) {
            this.store.set('lastHostory', lastHostory);
        }
        if (lastDataSource) {
            this.store.set('lastDataSource', lastDataSource);
        }
    }
    reOpen() {
        const lastFilePath = this.store.get('lastFilePath');
        const lastDatarray = this.store.get('lastDatarray');
        const lastHostory = this.store.get('lastHostory');
        const lastDataSource = this.store.get('lastDataSource');
        if (lastFilePath) {
            this.readFile(lastFilePath);
        }
        if (!!lastDatarray || !!lastHostory || !!lastDataSource) {
            this.sendHistoryToRender({ lastDatarray, lastHostory, lastDataSource });
        }
    }
    getHistory() {
        global.mainWindow.webContents.send('getHistory');
    }
    getDownloadPath() {
        const downloadPath = this.store.get('downloadPath') || electron_1.app.getPath('downloads');
        return downloadPath;
    }
    setDownloadPath(downloadPath) {
        this.store.set('downloadPath', downloadPath);
    }
    sendHistoryToRender(params) {
        global.mainWindow.webContents.send('sendHistoryToRender', params);
    }
}
exports.FileCenter = FileCenter;
