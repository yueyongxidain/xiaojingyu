(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[3],{

/***/ 59:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.translate = void 0; // 定义坐标系椭球参数对象

var wgs84 = {
  a: 6378137,
  b: 6356752.3142451795,
  f: 1 / 298.257223563
};

var square = num => num * num; //快速计算平方


var d2r = Math.PI / 180; //弧度 = 角度 * Math.PI / 180

/*
*   RE：Reference Ellipsoid（参考椭球体）
*   data: 一个存放数据的对象
*/

function BLHtoXYZ(RE, data) {
  var B = data.B;
  var L = data.L;
  var H = data.H;
  var e2 = (square(RE.a) - square(RE.b)) / square(RE.a);
  var N = RE.a / Math.sqrt(1 - e2 * square(Math.sin(B * d2r)));
  var X = (N + H) * Math.cos(B * d2r) * Math.cos(L * d2r);
  var Y = (N + H) * Math.cos(B * d2r) * Math.sin(L * d2r);
  var Z = (N * (1 - e2) + H) * Math.sin(B * d2r);
  var result = {
    X: +X.toFixed(2),
    Y: +Y.toFixed(2),
    Z: +Z.toFixed(2)
  }; //将结果保存到result对象中

  return result;
}

function index(B, L, H) {
  var position = BLHtoXYZ(wgs84, {
    B,
    L,
    H
  });
  return position;
}

exports.default = index;

function translate(ratioString) {
  var [d, m, s] = (ratioString === null || ratioString === void 0 ? void 0 : ratioString.split(':')) || [];
  var ratio = !!ratioString ? +d + +m / 60 + +s / 3600 : 0;
  return ratio;
}

exports.translate = translate;

/***/ }),

/***/ 62:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var __awaiter = this && this.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }

  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }

    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }

    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }

    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.downloadFile = exports.exists = exports.apiFetchPostFileChunk = exports.apiFetchPostFile = exports.apiFetchPut = exports.apiFetchDelete = exports.apiFetchPost = exports.apiFetchGet = exports.apiFetch = exports.iterate = exports.unintercept = exports.intercept = void 0;

var _ = __webpack_require__(35);

var qs = __webpack_require__(63);

var API_HOST = '';
var API_BASE = "".concat(API_HOST); // 拦截器集合

var interceptors = [];
/**
 * 添加拦截器
 * @param interceptor
 */

function intercept(interceptor) {
  var index = interceptors.indexOf(interceptor);

  if (index === -1) {
    interceptors.push(interceptor);
  }
}

exports.intercept = intercept;
/**
 * 移除拦截器
 * @param interceptor
 */

function unintercept(interceptor) {
  var index = interceptors.indexOf(interceptor);

  if (index !== -1) {
    interceptors.splice(index, 1);
  }
}

exports.unintercept = unintercept;
/**
 * 拦截器校验
 * @param funcProp 所需要校验的方法
 * @param params
 */

function iterate(funcProp, params) {
  interceptors.map(interceptor => {
    if (interceptor[funcProp]) {
      try {
        var callback = interceptor[funcProp];
        callback(params);
      } catch (e) {// error(e)
      }
    }
  });
}

exports.iterate = iterate;
/**
 * 基础 api 请求方法
 * @param input
 * @param init
 */

function apiFetch(input) {
  var init = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var extendedOpts = _.merge(init, {
    headers: {
      Accept: 'application/json',
      'X-Client-Request-ID': Math.random().toString(32).substr(2),
      'Cache-control': 'no-cache'
    },
    redirect: 'follow'
  }); // 拦截器处理 onRequest 方法，reduce 可保留每次处理过后 params


  var params = interceptors.reduce((_params, interceptor) => {
    if (interceptor.onRequest) {
      try {
        return interceptor.onRequest(_params);
      } catch (e) {
        return _params;
      }
    } else {
      return _params;
    }
  }, {
    input,
    init: extendedOpts
  });
  return fetch("".concat(API_BASE).concat(params.input), params.init).then(res => {
    // 拦截器处理 onResponse 方法
    iterate('onResponse', res);
    return Promise.all([res.status, res.statusText, res.status === 204 ? null : res.text()]);
  }, e => {
    // it will only reject on network failure or
    // if anything prevented the request from completing.
    // error(e)]
    return Promise.reject(e);
  }).then(_ref => {
    var [status, statusText, data] = _ref;
    var jsonData;

    try {
      jsonData = JSON.parse(data);
    } catch (e) {
      jsonData = {
        code: status,
        message: data ? data : statusText
      };
    }

    if (status < 200 || status >= 300) {
      return Promise.reject(jsonData);
    } // 拦截器处理 onData 方法


    iterate('onData', jsonData);
    return jsonData;
  }, e => {
    // res.json() rejected
    // error(e)
    return Promise.reject(e);
  });
}

exports.apiFetch = apiFetch;

function apiFetchGet(url) {
  var query = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var headers = arguments.length > 2 ? arguments[2] : undefined;
  return apiFetch("".concat(url, "?").concat(qs.stringify(query)), {
    headers
  });
}

exports.apiFetchGet = apiFetchGet;

function apiFetchPost(url, body, headers) {
  headers = headers || {};
  return apiFetch(url, {
    method: 'POST',
    headers: _.merge(headers, {
      'Content-Type': 'application/json'
    }),
    credentials: 'include',
    body: JSON.stringify(body)
  });
}

exports.apiFetchPost = apiFetchPost;

function apiFetchDelete(url, body, headers) {
  headers = headers || {};
  return apiFetch(url, {
    method: 'DELETE',
    headers: _.merge(headers, {
      'Content-Type': 'application/json'
    }),
    credentials: 'include',
    body: JSON.stringify(body)
  });
}

exports.apiFetchDelete = apiFetchDelete;

function apiFetchPut(url, body, headers) {
  headers = headers || {};
  return apiFetch(url, {
    method: 'PUT',
    headers: _.merge(headers, {
      'Content-Type': 'application/json'
    }),
    credentials: 'include',
    body: JSON.stringify(body)
  });
}

exports.apiFetchPut = apiFetchPut;

function apiFetchPostFile(url) {
  var body = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var file = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
  var data = new FormData();

  _.forEach(body, (val, key) => {
    data.append(key, val);
  });

  if (file) {
    data.append('file', file, file.name);
  }

  return apiFetch(url, {
    method: 'POST',
    credentials: 'include',
    body: data
  });
}

exports.apiFetchPostFile = apiFetchPostFile;

function apiFetchPostFileChunk(url) {
  var body = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var chunk = arguments.length > 2 ? arguments[2] : undefined;
  var data = new FormData();

  _.forEach(body, (val, key) => {
    data.append(key, val);
  });

  data.append('file', chunk);
  return apiFetch(url, {
    method: 'POST',
    credentials: 'include',
    body: data
  });
}

exports.apiFetchPostFileChunk = apiFetchPostFileChunk;

function exists(url) {
  return fetch(url, {
    method: 'HEAD'
  }).then(res => res.ok).catch(() => false);
}

exports.exists = exists;

function downloadFile(url) {
  return __awaiter(this, void 0, void 0, function* () {
    var endPoint = url.split('?')[0];
    var filename = endPoint.substring(endPoint.lastIndexOf('/') + 1);
    var a = window.document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    a.remove();
  });
}

exports.downloadFile = downloadFile;

/***/ })

}]);