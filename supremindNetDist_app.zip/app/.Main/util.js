"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteFolder = exports.fileSize = exports.fsExit = void 0;
const fs = require("fs");
const path = require("path");
const _ = require("lodash");
const child_process_1 = require("child_process");
const electron_1 = require("electron");
const electronLog = require("electron-log");
const fsExit = (filepath) => {
    fs.accessSync(filepath || '', fs.constants.F_OK);
};
exports.fsExit = fsExit;
// 同步获取文件大小
const fileSize = (filepath, hasUnit = false) => {
    if (!!filepath) {
        try {
            fsExit(filepath);
            if (process.platform === 'darwin') {
                const realFilepath = filepath.replace(/\s/g, '\\ ');
                const cmd = `du ${hasUnit ? '-sh' : '-s -k'} ${realFilepath}`;
                const count = child_process_1.execSync(cmd);
                const detail = count.toString().split('/')[0];
                return hasUnit ? _.trim(detail) : _.ceil(_.trim(detail));
            }
            else {
                const duPath = path.resolve(electron_1.app.isPackaged ? process.resourcesPath : '../', './extraResources/du.exe');
                const cmd = `${duPath} -u "${filepath}" /accepteula`;
                let count = child_process_1.execSync(cmd);
                count = count.toString();
                let detail;
                let totalB;
                let totalK;
                detail = count.toString().match(/Size\:\s+((\d+,)*\d+) byte/);
                if (detail && detail.length > 0) {
                    detail = detail[1];
                    totalB = detail.replace(/\,/g, '') * 1 || 1;
                    totalK = (totalB / 1024).toFixed(1);
                }
                if (!hasUnit) {
                    return totalK;
                }
                else {
                    const totalM = (totalB / 1024 / 1024).toFixed(1);
                    const totalG = (totalB / 1024 / 1024 / 1024).toFixed(1);
                    if (_.toNumber(totalG) > 0.1) {
                        return totalG + 'GB';
                    }
                    if (_.toNumber(totalM) > 0.1) {
                        return totalM + 'MB';
                    }
                    return totalK + 'KB';
                }
            }
        }
        catch (e) {
            electronLog.error(e);
            electron_1.dialog.showMessageBox({
                message: e.message
            });
            return 1;
        }
    }
    return 1;
};
exports.fileSize = fileSize;
function deleteFolder(filePath) {
    return __awaiter(this, void 0, void 0, function* () {
        let files = [];
        if (fs.existsSync(filePath)) {
            files = yield fs.promises.readdir(filePath);
            for (const file of files) {
                const nextFilePath = `${filePath}/${file}`;
                const states = fs.statSync(nextFilePath);
                if (states.isDirectory()) {
                    // recurse
                    yield deleteFolder(nextFilePath);
                }
                else {
                    // delete file
                    fs.unlinkSync(nextFilePath);
                }
            }
            fs.rmdirSync(filePath);
        }
    });
}
exports.deleteFolder = deleteFolder;
