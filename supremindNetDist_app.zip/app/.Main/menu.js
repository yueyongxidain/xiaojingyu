"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GlobalMenu = void 0;
const electron_1 = require("electron");
const setting_1 = require("./window/setting");
const isMac = process.platform === 'darwin';
class GlobalMenu {
    constructor() {
        this.template = [
            // { role: 'appMenu' }
            ...(isMac
                ? [
                    {
                        label: electron_1.app.name,
                        submenu: [
                            { role: 'about', label: '关于' },
                            { type: 'separator' },
                            { role: 'hide', label: '隐藏' },
                            { type: 'separator' },
                            { role: 'quit', label: '退出' }
                        ]
                    }
                ]
                : []),
            // { role: 'fileMenu' }
            {
                label: '文件',
                submenu: [
                    { label: '打开', click: () => this.openFile() },
                    { type: 'separator' },
                    { label: '保存', click: () => this.saveFile() },
                    { type: 'separator' },
                    { label: '数据导出', click: () => this.saveAs() }
                ]
            },
            {
                role: 'help',
                submenu: [
                    {
                        label: 'Learn More',
                        click: () => __awaiter(this, void 0, void 0, function* () {
                            const { shell } = require('electron');
                            yield shell.openExternal('https://electronjs.org');
                        })
                    }
                ]
            }
        ];
        this.instance = electron_1.Menu.buildFromTemplate(this.template);
    }
    openFile() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.instance) {
                return;
            }
            const filePathResult = yield electron_1.dialog.showOpenDialog(global.mainWindow, {
                title: '选择数据文件',
                filters: [{ name: 'txt/csv', extensions: ['txt', 'csv'] }],
                properties: ['openFile']
            });
            global.fileCenter.readFile(filePathResult.filePaths[0]);
            global.fileCenter.saveHistory(filePathResult.filePaths[0], undefined, undefined, undefined);
        });
    }
    saveFile() {
        if (!this.instance) {
            return;
        }
        global.fileCenter.getHistory();
    }
    saveAs() {
        if (!this.instance) {
            return;
        }
        setting_1.createSettingWindow(undefined, {});
        console.log('另存为');
    }
}
exports.GlobalMenu = GlobalMenu;
