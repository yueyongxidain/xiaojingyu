"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UPLOAD_CLIENT = exports.EXIT_CODE = exports.TASK_DATA_TYPE = exports.DELETE_OPTIONS = exports.DOWNLOADMOD = exports.DISCARD_REASON = exports.MimeType = exports.ACTION_TYPE = exports.ORE_TYPES = exports.TASK_SOURCE = exports.TASK_TYPE = void 0;
var TASK_TYPE;
(function (TASK_TYPE) {
    TASK_TYPE[TASK_TYPE["WATING"] = 0] = "WATING";
    TASK_TYPE[TASK_TYPE["PLAY"] = 1] = "PLAY";
    TASK_TYPE[TASK_TYPE["PAUSED"] = 2] = "PAUSED";
    TASK_TYPE[TASK_TYPE["FINISH"] = 3] = "FINISH";
    TASK_TYPE[TASK_TYPE["ERROR"] = 4] = "ERROR";
    TASK_TYPE[TASK_TYPE["GETJSON"] = 5] = "GETJSON";
    TASK_TYPE[TASK_TYPE["METACHEKING"] = 6] = "METACHEKING";
})(TASK_TYPE = exports.TASK_TYPE || (exports.TASK_TYPE = {}));
var TASK_SOURCE;
(function (TASK_SOURCE) {
    TASK_SOURCE[TASK_SOURCE["VISIONMIND"] = 0] = "VISIONMIND";
    TASK_SOURCE[TASK_SOURCE["LOCAL"] = 1] = "LOCAL";
})(TASK_SOURCE = exports.TASK_SOURCE || (exports.TASK_SOURCE = {}));
var ORE_TYPES;
(function (ORE_TYPES) {
    ORE_TYPES[ORE_TYPES["FILES"] = 0] = "FILES";
    ORE_TYPES[ORE_TYPES["EVENT"] = 1] = "EVENT";
    ORE_TYPES[ORE_TYPES["ILLEGAL"] = 2] = "ILLEGAL";
    ORE_TYPES[ORE_TYPES["DISCARD"] = 3] = "DISCARD";
    ORE_TYPES[ORE_TYPES["MISS"] = 4] = "MISS";
})(ORE_TYPES = exports.ORE_TYPES || (exports.ORE_TYPES = {}));
var ACTION_TYPE;
(function (ACTION_TYPE) {
    ACTION_TYPE[ACTION_TYPE["UPLOAD"] = 0] = "UPLOAD";
    ACTION_TYPE[ACTION_TYPE["DOWNLOAD"] = 1] = "DOWNLOAD";
    ACTION_TYPE[ACTION_TYPE["DELETE"] = 2] = "DELETE";
    ACTION_TYPE[ACTION_TYPE["PREDATA"] = 3] = "PREDATA";
})(ACTION_TYPE = exports.ACTION_TYPE || (exports.ACTION_TYPE = {}));
var MimeType;
(function (MimeType) {
    MimeType[MimeType["OTHER"] = 0] = "OTHER";
    MimeType[MimeType["IMAGE"] = 1] = "IMAGE";
    MimeType[MimeType["VIDEO"] = 2] = "VIDEO";
    MimeType[MimeType["JSON"] = 3] = "JSON";
    MimeType[MimeType["TMP"] = 4] = "TMP";
})(MimeType = exports.MimeType || (exports.MimeType = {}));
exports.DISCARD_REASON = {
    0: '其他',
    221: '其他',
    229: '测试正确',
    201: '检测错误',
    202: '判断错误',
    211: '取证问题',
    212: '无人脸信息',
    121: '其他',
    129: '测试正确',
    101: '检测错误',
    104: '大车问题',
    114: '夜晚问题',
    113: '白名单车',
    102: '判断错误',
    103: '跟踪错误',
    112: '车牌模糊'
};
var DOWNLOADMOD;
(function (DOWNLOADMOD) {
    DOWNLOADMOD[DOWNLOADMOD["DEFAULT"] = 0] = "DEFAULT";
    DOWNLOADMOD[DOWNLOADMOD["PLUGIN"] = 1] = "PLUGIN";
})(DOWNLOADMOD = exports.DOWNLOADMOD || (exports.DOWNLOADMOD = {}));
var DELETE_OPTIONS;
(function (DELETE_OPTIONS) {
    DELETE_OPTIONS[DELETE_OPTIONS["RECORD"] = 0] = "RECORD";
    DELETE_OPTIONS[DELETE_OPTIONS["WITHFILE"] = 1] = "WITHFILE";
    DELETE_OPTIONS[DELETE_OPTIONS["ALWAYSASK"] = 2] = "ALWAYSASK";
})(DELETE_OPTIONS = exports.DELETE_OPTIONS || (exports.DELETE_OPTIONS = {}));
var TASK_DATA_TYPE;
(function (TASK_DATA_TYPE) {
    TASK_DATA_TYPE["ALL"] = "0";
    TASK_DATA_TYPE["IMAGE"] = "1";
    TASK_DATA_TYPE["VIDEO"] = "2";
})(TASK_DATA_TYPE = exports.TASK_DATA_TYPE || (exports.TASK_DATA_TYPE = {}));
var EXIT_CODE;
(function (EXIT_CODE) {
    EXIT_CODE[EXIT_CODE["ERROR"] = 1] = "ERROR";
    EXIT_CODE[EXIT_CODE["RSYNC_20"] = 20] = "RSYNC_20";
    // https://lxadm.com/Rsync_exit_codes
    EXIT_CODE[EXIT_CODE["RSYNC_10"] = 10] = "RSYNC_10";
    EXIT_CODE[EXIT_CODE["RSYNC_12"] = 12] = "RSYNC_12";
    EXIT_CODE[EXIT_CODE["RSYNC_30"] = 30] = "RSYNC_30"; // Timeout in data send/receive
})(EXIT_CODE = exports.EXIT_CODE || (exports.EXIT_CODE = {}));
var UPLOAD_CLIENT;
(function (UPLOAD_CLIENT) {
    UPLOAD_CLIENT[UPLOAD_CLIENT["WEB"] = 1] = "WEB";
    UPLOAD_CLIENT[UPLOAD_CLIENT["SUPREANT"] = 2] = "SUPREANT";
    UPLOAD_CLIENT[UPLOAD_CLIENT["CLI"] = 3] = "CLI";
})(UPLOAD_CLIENT = exports.UPLOAD_CLIENT || (exports.UPLOAD_CLIENT = {}));
