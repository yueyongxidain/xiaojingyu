"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const fileCenter_1 = require("./fileCenter");
const menu_1 = require("./menu");
const main_1 = require("./window/main");
global.config = {
    COMMAND_LINE: {
        'disable-web-security': true,
        'ignore-certificate-errors': true
    }
};
class SupreAntApp {
    init() {
        // 初始化
        this.singleton();
        this.registeWindow();
        this.registeCommandLine();
        this.registeMenu();
        this.registeFileCenter();
    }
    /**
     * app 单例模式
     */
    singleton() {
        const gotTheLock = electron_1.app.requestSingleInstanceLock();
        if (!gotTheLock) {
            electron_1.app.quit();
        }
        electron_1.app.on('second-instance', (event, commandLine, workingDirectory) => {
            // 当运行第二个实例时,将会聚焦到myWindow这个窗口
            if (global.mainWindow) {
                if (global.mainWindow.isMinimized()) {
                    global.mainWindow.restore();
                }
                global.mainWindow.focus();
            }
            if (global.loginWindow) {
                if (global.loginWindow.isMinimized()) {
                    global.loginWindow.restore();
                }
                global.loginWindow.focus();
            }
        });
    }
    /**
     * 更具用户处于不同的状态创建不同的窗口
     * 1）公司用户登录模式
     * 2）离线模式
     * 3）登出模式
     */
    registeWindow() {
        // 处于登录状态
        if (global.mainWindow) {
            if (global.mainWindow.isMinimized()) {
                global.mainWindow.restore();
            }
            global.mainWindow.focus();
        }
        else {
            main_1.createMainWindow();
        }
    }
    registeCommandLine() {
        const commandLines = global.config.COMMAND_LINE;
        for (const key in commandLines) {
            if (commandLines.hasOwnProperty(key)) {
                const value = commandLines[key];
                if (value) {
                    electron_1.app.commandLine.appendSwitch(key, value);
                }
            }
        }
    }
    registeFileCenter() {
        global.fileCenter = new fileCenter_1.FileCenter();
        electron_1.ipcMain.on('export', (event, params) => {
            global.fileCenter.getDataFromRender(params);
        });
        electron_1.ipcMain.on('getDownloadPath', (event, params) => {
            const downloadPath = global.fileCenter.getDownloadPath(params);
            global.settingWindow.webContents.send('downloadPath', { downloadPath });
        });
        electron_1.ipcMain.on('showSaveAs', (event, params) => __awaiter(this, void 0, void 0, function* () {
            const filePathResult = yield electron_1.dialog.showOpenDialog(global.mainWindow, {
                title: '选择数据文件夹',
                properties: ['openDirectory']
            });
            global.fileCenter.setDownloadPath(filePathResult.filePaths[0]);
            global.settingWindow.webContents.send('downloadPath', {
                downloadPath: filePathResult.filePaths[0]
            });
        }));
        electron_1.ipcMain.on('sendDataSource', (event, params) => {
            try {
                const filePath = global.fileCenter.saveAs(params);
                new electron_1.Notification({
                    title: '导出成功',
                    body: `文件存储到：${filePath}`
                }).show();
                global.settingWindow.webContents.send('finishExport');
            }
            catch (err) {
                new electron_1.Notification({
                    title: '导出失败',
                    body: `失败信息：${err.message}`
                }).show();
                global.settingWindow.webContents.send('errorExport');
            }
            // TODO 通知导出页面 完成导出
        });
        electron_1.ipcMain.on('getReOpen', (event, params) => {
            global.fileCenter.reOpen();
        });
        electron_1.ipcMain.on('sendHistory', (event, params) => {
            const { dataArray, dataSource, history } = params;
            global.fileCenter.saveHistory(undefined, dataArray, history, dataSource);
        });
    }
    /**
     * 菜单设置
     */
    registeMenu() {
        const globalMenu = new menu_1.GlobalMenu();
        return globalMenu;
    }
}
const supreAnt = new SupreAntApp();
// app 周期方法函数
electron_1.app.on('ready', () => {
    supreAnt.init();
});
