"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUpload = exports.createPackhorseJob = exports.updateAtworkMine = exports.updatePackhorseJob = void 0;
const fetch_1 = require("./fetch");
function updatePackhorseJob(params) {
    return __awaiter(this, void 0, void 0, function* () {
        return fetch_1.apiFetchPost(`${global.config.PACKHORSE}/v1/job/upload/update`, params);
    });
}
exports.updatePackhorseJob = updatePackhorseJob;
function updateAtworkMine(params) {
    return __awaiter(this, void 0, void 0, function* () {
        return fetch_1.apiFetchPost(`${global.config.ATWORK}/api/mine`, params);
    });
}
exports.updateAtworkMine = updateAtworkMine;
function createPackhorseJob(params) {
    return __awaiter(this, void 0, void 0, function* () {
        return fetch_1.apiFetchPost(`${global.config.PACKHORSE}/v1/job/upload/create`, params);
    });
}
exports.createPackhorseJob = createPackhorseJob;
function createUpload(params) {
    return __awaiter(this, void 0, void 0, function* () {
        return fetch_1.apiFetchPost(`${global.config.ATWORK}/api/uploads`, params);
    });
}
exports.createUpload = createUpload;
