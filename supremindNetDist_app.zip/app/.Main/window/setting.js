"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSettingWindow = void 0;
const electron_1 = require("electron");
const path = require("path");
const url = require("url");
// 设置窗口
function createSettingWindow() {
    if (global.settingWindow) {
        global.settingWindow.restore();
        return;
    }
    const hash = `#`;
    electron_1.Menu.setApplicationMenu(null);
    const window = new electron_1.BrowserWindow({
        width: 438,
        height: 300,
        fullscreen: false,
        fullscreenable: false,
        title: '数据导出',
        autoHideMenuBar: false,
        resizable: false,
        parent: global.mainWindow,
        icon: process.platform !== 'darwin' &&
            (!!electron_1.app.isPackaged
                ? path.join(__dirname, '../.Render/favicon.ico')
                : path.join(__dirname, '../../render/public/favicon.ico')),
        webPreferences: {
            nodeIntegration: true,
            preload: path.join(__dirname, './preload.js'),
            devTools: true
        },
        minimizable: false,
        show: false
    });
    if (!!electron_1.app.isPackaged) {
        window.loadURL(url.format({
            pathname: path.join(__dirname, '../.Render/setting.html'),
            protocol: 'file:',
            hash,
            slashes: true
        }));
    }
    else {
        window.loadURL(`http://localhost:3000/setting.html${hash}`);
        window.webContents.openDevTools();
    }
    global.settingWindow = window;
    window.on('ready-to-show', function () {
        // 初始化后再显示
        window.show();
        // 位置移动特效
        const mainBound = global.mainWindow.getBounds();
        window.setBounds({
            x: Math.ceil(mainBound.x + mainBound.width / 2 - 480 / 2),
            y: Math.ceil(mainBound.y + mainBound.height / 2 - 342 / 2)
        }, true);
    });
    window.on('close', function () {
        global.settingWindow = null;
    });
    return window;
}
exports.createSettingWindow = createSettingWindow;
