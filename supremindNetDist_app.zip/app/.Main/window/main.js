"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.closeMainWindow = exports.createMainWindow = void 0;
const electron_1 = require("electron");
const path = require("path");
const url = require("url");
// 操作窗口
function createMainWindow() {
    if (global.mainWindow) {
        return;
    }
    electron_1.Menu.setApplicationMenu(null);
    // 检测剪切板是否存在可疑的任务
    const hash = `#`;
    const window = new electron_1.BrowserWindow({
        width: 1020,
        height: 647,
        resizable: false,
        autoHideMenuBar: true,
        minimizable: true,
        show: false,
        titleBarStyle: 'hidden',
        icon: process.platform !== 'darwin' &&
            (!!electron_1.app.isPackaged
                ? path.join(__dirname, '../.Render/favicon.ico')
                : path.join(__dirname, '../../render/public/favicon.ico')),
        title: '小鲸鱼',
        transparent: false,
        frame: false,
        webPreferences: {
            preload: path.join(__dirname, './preload.js'),
            nodeIntegration: true,
            devTools: true
        }
    });
    if (!!electron_1.app.isPackaged) {
        // 生产
        window.loadURL(url.format({
            pathname: path.join(__dirname, '../.Render/main.html'),
            hash,
            protocol: 'file:',
            slashes: true
        }));
        // window.webContents.openDevTools()
    }
    else {
        // 开发测试
        window.loadURL(`http://localhost:3000/main.html${hash}`);
        // window.loadURL(
        //   url.format({
        //     pathname: path.join(__dirname, '../../../.Render/main.html'), // 注意这里修改
        //     hash,
        //     protocol: 'file:',
        //     slashes: true
        //   })
        // )
        window.webContents.openDevTools();
    }
    global.mainWindow = window;
    window.on('ready-to-show', function () {
        window.show(); // 初始化后再显示
    });
    window.on('close', function () {
        global.mainWindow = undefined;
    });
    return window;
}
exports.createMainWindow = createMainWindow;
function closeMainWindow() {
    if (global.mainWindow) {
        global.mainWindow.close();
        global.mainWindow = undefined;
    }
}
exports.closeMainWindow = closeMainWindow;
